
-- 1. 기본 데이터 확인
SELECT id, body, content_hash
FROM `gen-lang-client-0790720774.descent_demo.raw_texts`
ORDER BY id
LIMIT 5;
        